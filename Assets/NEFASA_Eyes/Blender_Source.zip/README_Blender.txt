NEFASA BLENDER EYES 1.3

1. Blender/Augen_Original.blend öffnen. Augen_Demo.blend enthält zusätzlich ein fertiges Studio für F12.
2. „Augenfarbe einstellen“ im Outliner auswählen.
3. Rechts auf den Schraubenschlüssel klicken → „Augenfarbe und Details“.
4. Augenfarbe und Innenfarbe auswählen. Beide Augen reagieren gemeinsam.
5. Pupillenradius und die sechs Detailregler nach Wunsch verändern.
6. „Sehnerv anzeigen“ ausschalten, wenn du die beiden hinteren Sehnerven nicht brauchst.
7. Für die geschichtete Hornhaut-Lichtbrechung Cycles verwenden.
8. In einem Charakterprojekt: Datei → Anfügen → Augen_Original.blend → Collection.
   „Augen“ und „Sehnerven – optional“ gemeinsam markieren und anfügen. Ohne Sehnerven nur „Augen“ wählen.
9. Den Hauptregler dem Kopf unterordnen und die Augen einzeln in den Augenhöhlen positionieren/ausrichten.
   Die optionalen feuchten Lidrand-Objekte sind zunächst ausgeblendet und müssen an die verwendeten Augenlider angepasst werden.

